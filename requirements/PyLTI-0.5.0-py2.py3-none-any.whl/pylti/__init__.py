# -*- coding: utf-8 -*-
"""
PyLTI is module that implements IMS LTI in python
The API uses decorators to wrap function with LTI functionality.
"""
VERSION = "0.5.0"  # pragma: no cover
